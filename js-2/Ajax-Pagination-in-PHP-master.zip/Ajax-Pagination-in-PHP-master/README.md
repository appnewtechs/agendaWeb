# Ajax-Pagination-in-PHP
Ajax Pagination in PHP by CodexWorld – Simple PHP Pagination class to implement pagination with jQuery Ajax PHP and MySQL.

## Tutorial
Read the full tutorial to implementing Ajax pagination in PHP from here - [Pagination with jQuery Ajax PHP and MySQL](http://www.codexworld.com/pagination-with-jquery-ajax-php-mysql/)

## License
Copyright 2015 [CodexWorld.com](http://www.codexworld.com)
